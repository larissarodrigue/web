<?php defined('BASEPATH') OR exit('No direct script access allowed');
 class Login extends CI_Controller {
		 private $pokemon;
			private $var;
 		 public function __construct(){
  	  			parent::__construct();
                    $this->load->model("Consulta", "model_consulta");
        $this->pokemon = $this->model_consulta->lista();
 		 }
  	public function index(){
		    $this->load->helper('text');
  		    $this->load->view('login');

   }
  
 }

