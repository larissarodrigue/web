<?php defined('BASEPATH') OR exit('No direct script access allowed') ;
 class Cadastro extends CI_Controller{
 public $pokemon;
	public function __construct () {
		parent::__construct();
      $this->load->library("session");
		}
		 public function index () {
		 $this->load->helper('text');
		 $this->load->view('html-header');
		 $this->load->view('header');
		 $this->load->view('cadastro');
		 $this->load->view('footer');
		 $this->load->view('html-footer') ;
		 }
    
}
