<body style="background-color:#b3ecff;">
<div class="container-fluid" >
    
  
    <nav class="navbar navbar-inverse">
      <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse-3">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button><img src="http://localhost/larissa/pokemon/assets/img/03.png" style=" width: 50px;height: 50px;">
          <strong><a class="navbar-brand" href="#">POKEMON G</a></strong>
        </div>
    
       
    
        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="navbar-collapse-4">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="http://localhost/larissa/pokemon/index.php/Cadastro">Cadastrar Pokemon</a></li>
            <li><a href="http://localhost/larissa/pokemon/index.php/Home">Consultar Pokemon</a></li>
            <li><a href="http://localhost/larissa/pokemon/index.php/Login">Sair</a></li>
          
          </ul>
          
        </div><!-- /.navbar-collapse -->
      </div><!-- /.container -->
    </nav><!-- /.navbar -->
</div><!-- /.container-fluid -->

