<center>


<fieldset>

<!-- Form Name -->

<div class="col-md-6 col-sm-6 col-xs-12">
<center><div id="formulario">
               <div class="panel panel-info">
                        <div class="panel-heading">
                           Cadastro de Pokemon
                        </div>
                        <div class="panel-body">
                            <form role="form">
                                        <div class="form-group">
                                            <label>Nome</label>
                                            <input class="form-control" type="text">
                                            <p class="help-block">Nome do seu pokemon.</p>
                                        </div>
                                 <div class="form-group">
                                            <label>Data</label>
                                            <input class="form-control" type="text">
                                     <p class="help-block">Data de Captura.</p>
                                       <div class="dropdown">
                              <label class="input-group">Tipo de Pokemon:</label>

                              <select data-toggle="dropdown" id="tipo" name="tipo_pokemon" class="btn btn-info dropdown-toggle" required=""><span class="caret"></span>
                                    <ul class="dropdown-menu">
                                        <option value="" disabled selected hidden>Tipo</option>
                                        <option value="Verde">Verde</option>
                                        <option value="Laranja">Laranja</option>
                                        <option value="Vermelho">Vermelho</option>

                                    </ul>
                              </select>

                            </div><br>
                                  
                                 
                                        <button type="submit" class="btn btn-info">Salvar </button>

                                    </form>                            </div>
                            </div></center>
                        </div>
                            </div>

	        <img src="http://localhost/larissa/pokemon/assets/img/04.png" >
</div>
</center>
