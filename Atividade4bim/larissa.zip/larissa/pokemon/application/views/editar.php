<center>
<div class="input-group">
  <form class="form-horizontal">
<fieldset>

<!-- Form Name -->
<legend>Editar</legend>
<div class ="alinhado-centro borda-base espaco-vertical">


  	</div>



  <div class="input-group">

  </div><br>
                            <div class="dropdown">
                              <label class="input-group">Tipo de Pokemon:</label>

                              <select data-toggle="dropdown" id="tipo" name="tipo_pokemon" class="btn btn-info dropdown-toggle" required=""><span class="caret"></span>
                                    <ul class="dropdown-menu">
                                        <option value="" disabled selected hidden>Tipo</option>
                                        <option value="Verde">Verde</option>
                                        <option value="Laranja">Laranja</option>
                                        <option value="Vermelho">Vermelho</option>

                                    </ul>
                              </select>

                            </div>
                            <br>
                            <div class="form-group">
                                <!-- Button -->
                                <div class="col-sm-12 controls">

                                        <button type="submit" href="#" class="btn btn-default"><i class="fa fa-sign-in"></i> Enviar</button>



                                </div>
                            </div>

                        </form>
	        <img src="http://localhost/larissa/pokemon/assets/img/02.png" >
</fieldset>
</form>
</div>
</center>
