<div class ="alinhado-centro borda-base espaco-vertical">
<div id="footer" class="borda-topo espaco-vertical">
<nav class="navbar navbar-inverse navbar-fixed-bottom">

      <div class="container" style="color:#fff;"><center>
       Todos os direitos reservados</center>
      </div><!-- /.container -->
    </nav><!-- /.navbar -->
  </div>
  </div>
