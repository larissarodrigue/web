<! DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
		<title> Meu Blog </title>
	</head>
	<body>
		<h3>E-mail enviado com sucesso!! </h3>
	</body>
</html>
