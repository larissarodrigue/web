<!DOCTYPE html>
<html lang ="pt-br">
	<head>
		<meta charset=" utf-8">
			<?php
				echo link_tag('https://fonts.googleapis.com/css?family=Roboto+Condensed');
				echo link_tag('assets/css/estilo.css');
			?>
	</head>
	<body>
		<h2>Referências Bibliográficas</h2>
		<?php
			echo anchor(base_url("welcome/pdf"), "Listagens das referências") 
		?>
		<br>
			
		<?php
			 echo anchor(base_url("welcome/cadastrar_ref") ,"Cadastrar nova referência");
		?>
		<br>
			
		<?php
			 echo anchor(base_url() ,"Consulta Referência");
		?>
	</body>
</html>
