<!DOCTYPE html>
<html lang ="pt-br">
	<head>
		<meta charset=" utf-8">
	</head>
	<body>

		<h2>Meu Blog</h2>
		<h3>Postagens Recentes</h3>
		<?php
		
		?>
	</body>
</html>
