<?php
	require 'assets/fpdf/fpdf.php';
	$pdf = new FPDF('P','pt','A4');
	$pdf->SetTitle('TestePDF1');
	$pdf->SetTitle('Izabela e Larissa');
	$pdf->SetCreator('php'.phpversion());
	$pdf->SetKeywords('php','php');
	$pdf->SetSubject('como criar um PDF');

	foreach($citacoes as $post) {
	
	$pdf->AddPage();
	$pdf->SetFont('arial', '', 12);
	
	$cabecalho = 'Referências' ;
	$cabecalho = utf8_decode($cabecalho);
	$pdf->Write(50,$cabecalho);
	$pdf->Ln(50);
	$pdf->SetX(60);
	
	$txt= ('Nome Arquivo: ' .$post->nomeArquivo);
	$txt = utf8_decode($txt);
	$pdf->Write(15,$txt);
	$pdf->Ln(15);
	$pdf->SetX(60);
	
	$txt=('Título: '.$post->titulo);
	$txt = utf8_decode($txt);
	$pdf->Write(15,$txt);
	$pdf->Ln(15);
	$pdf->SetX(60);
	
	$txt=('Autores: '.$post->autores);
	$txt = utf8_decode($txt);
	$pdf->Write(15,$txt);
	$pdf->Ln(15);
	$pdf->SetX(60);
	
	$txt=('Citações: '.$post->citacoes);
	$txt = utf8_decode($txt);
	$pdf->Write(15,$txt);
	$pdf->Ln(15);
	$pdf->SetX(60);
	
	$txt=('Referêcias: '.$post->referencias);
	$txt = utf8_decode($txt);
	$pdf->Write(15,$txt);
	$pdf->Ln(15);
	$pdf->SetX(60);
	
	$txt=('Palavras-chave: '.$post->palavrasChave);
	$txt = utf8_decode($txt);
	$pdf->Write(15,$txt);
	$pdf->Ln(15);
	$pdf->SetX(60);
	
	$txt=('Data Cadastro: '.$post->dataCadastro);
	$txt = utf8_decode($txt);
	$pdf->Write(15,$txt);
	$pdf->Ln(15);
	$pdf->SetX(60);
}
	$pdf->Output();
	
	
?>
