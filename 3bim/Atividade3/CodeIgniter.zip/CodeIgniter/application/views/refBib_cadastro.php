<!DOCTYPE html>
<html lang ="pt-br">
	<head>
		<meta charset=" utf-8">
	</head>
	<body>
		<?php
			echo anchor(base_url(), "Início"));
		?>
		<h3>Inserir nova referência</h3>
		<?php
	
		?>
	</body>
</html>
