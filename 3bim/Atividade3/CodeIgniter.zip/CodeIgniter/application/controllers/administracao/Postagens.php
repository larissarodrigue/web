<?php defined('BASEPATH') OR exit('No direct script access allowed');
	class Postagens extends CI_Controller{
		public function index(){
			$data ['postagens'] = $this->db->get('postagens')->result() ;
			$this->load->helper('form');
			$this->load->view('administracao/nova_postagem');
		}
		public function adicionar(){
			$data ['titulo'] = $this->input->post('txt_titulo');
			$data ['texto'] = $this->input->post('txt_texto');
			if($this->db->insert('postagens', $data)){
				redirect(base_url('administracao/postagens'));
			} else{
				echo "Não foi possível gravar a postagem no banco de dados ";
			}
		}
		 public function salvar_alteracao(){
			$data ['titulo'] = $this->input->post('txt_titulo');
			$data ['texto'] = $this->input->post('txt_texto');
			$this->db->where('id', $this->input->post('id'));
			if($this->db->update('postagens', $data)){
				redirect(base_url('administracao/postagens'));
			}else{
				echo "Não foi possível gravar a alteração da postagem no banco de dados ";
			}
		}
	}
